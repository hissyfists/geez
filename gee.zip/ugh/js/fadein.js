

   var speed=100; /* edit this value to suit */
   var c=0;

function init(){
document.getElementById('logo').style.opacity=c/100;
if(c==100){
   return;
 }
   c++;
   setTimeout(function(){init()},speed);
 }
   window.addEventListener?
   window.addEventListener('load',init,false):
   window.attachEvent('onload',init);
